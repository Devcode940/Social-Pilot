import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";

// ─── tryCatch Wrapper ─────────────────────────────────────────────────────────
// Wraps an async handler to standardize error responses

type ApiHandler = (
  request: NextRequest
) => Promise<NextResponse> | NextResponse;

export function tryCatch(handler: ApiHandler): ApiHandler {
  return async (request: NextRequest) => {
    try {
      return await handler(request);
    } catch (error) {
      console.error("[API Error]", error);

      if (error instanceof z.ZodError) {
        return NextResponse.json(
          {
            success: false,
            message: "Validation error",
            errors: error.issues.map((e) => ({
              path: e.path.join("."),
              message: e.message,
            })),
          },
          { status: 400 }
        );
      }

      if (error instanceof SyntaxError) {
        return NextResponse.json(
          {
            success: false,
            message: "Invalid JSON in request body",
          },
          { status: 400 }
        );
      }

      const message =
        error instanceof Error ? error.message : "Internal server error";

      return NextResponse.json(
        {
          success: false,
          message,
        },
        { status: 500 }
      );
    }
  };
}

// ─── validateBody ─────────────────────────────────────────────────────────────
// Validates request body against a Zod schema

export async function validateBody<T>(
  request: NextRequest,
  schema: z.ZodType<T>
): Promise<{ success: true; data: T } | { success: false; response: NextResponse }> {
  try {
    const body = await request.json();
    const result = schema.safeParse(body);

    if (!result.success) {
      return {
        success: false,
        response: NextResponse.json(
          {
            success: false,
            message: "Request validation failed",
            errors: result.error.issues.map((e) => ({
              path: e.path.join("."),
              message: e.message,
            })),
          },
          { status: 400 }
        ),
      };
    }

    return { success: true, data: result.data };
  } catch {
    return {
      success: false,
      response: NextResponse.json(
        {
          success: false,
          message: "Invalid or missing JSON body",
        },
        { status: 400 }
      ),
    };
  }
}

// ─── withAuth ─────────────────────────────────────────────────────────────────
// Higher-order function that checks for a valid session before proceeding

type ProtectedHandler = (
  request: NextRequest,
  session: { userId: string; email: string }
) => Promise<NextResponse> | NextResponse;

export function withAuth(handler: ProtectedHandler): ApiHandler {
  return async (request: NextRequest) => {
    try {
      // Check for authorization header (Bearer token)
      const authHeader = request.headers.get("authorization");
      if (authHeader?.startsWith("Bearer ")) {
        const token = authHeader.slice(7);

        // In production, this would verify the JWT token
        // For now, we accept any non-empty token as valid for the demo
        if (!token) {
          return NextResponse.json(
            {
              success: false,
              message: "Invalid or missing authentication token",
            },
            { status: 401 }
          );
        }
      }

      // For the demo app, we find the first user as the authenticated user
      // In production with NextAuth, this would use getServerSession()
      const { db } = await import("@/lib/db");
      const user = await db.user.findFirst();

      if (!user) {
        return NextResponse.json(
          {
            success: false,
            message: "No authenticated user found",
          },
          { status: 401 }
        );
      }

      return await handler(request, {
        userId: user.id,
        email: user.email,
      });
    } catch (error) {
      console.error("[Auth Error]", error);
      return NextResponse.json(
        {
          success: false,
          message: "Authentication check failed",
        },
        { status: 500 }
      );
    }
  };
}

// ─── rateLimit ────────────────────────────────────────────────────────────────
// Simple in-memory rate limiter (map of IP -> count)

interface RateLimitEntry {
  count: number;
  resetAt: number;
}

const rateLimitStore = new Map<string, RateLimitEntry>();

// Cleanup old entries every 5 minutes
setInterval(() => {
  const now = Date.now();
  for (const [key, entry] of rateLimitStore.entries()) {
    if (entry.resetAt <= now) {
      rateLimitStore.delete(key);
    }
  }
}, 5 * 60 * 1000);

export interface RateLimitOptions {
  /** Maximum number of requests in the window (default: 60) */
  maxRequests?: number;
  /** Window duration in seconds (default: 60) */
  windowSeconds?: number;
  /** Custom identifier (defaults to IP address) */
  identifier?: string;
}

export interface RateLimitResult {
  /** Whether the request is allowed */
  allowed: boolean;
  /** Number of remaining requests in the current window */
  remaining: number;
  /** Unix timestamp when the rate limit resets */
  resetAt: number;
  /** Total limit for the window */
  limit: number;
}

export function rateLimit(
  request: NextRequest,
  options: RateLimitOptions = {}
): RateLimitResult {
  const {
    maxRequests = 60,
    windowSeconds = 60,
    identifier,
  } = options;

  // Determine identifier: custom or IP-based
  let key: string;
  if (identifier) {
    key = identifier;
  } else {
    // Try to get real IP from headers (reverse proxy friendly)
    const forwarded = request.headers.get("x-forwarded-for");
    const realIp = request.headers.get("x-real-ip");
    const ip = forwarded?.split(",")[0]?.trim() || realIp || "unknown";
    key = ip;
  }

  const now = Date.now();
  const windowMs = windowSeconds * 1000;

  const entry = rateLimitStore.get(key);

  if (!entry || entry.resetAt <= now) {
    // Create new window
    const newEntry: RateLimitEntry = {
      count: 1,
      resetAt: now + windowMs,
    };
    rateLimitStore.set(key, newEntry);

    return {
      allowed: true,
      remaining: maxRequests - 1,
      resetAt: newEntry.resetAt,
      limit: maxRequests,
    };
  }

  // Increment count in existing window
  entry.count += 1;

  if (entry.count > maxRequests) {
    return {
      allowed: false,
      remaining: 0,
      resetAt: entry.resetAt,
      limit: maxRequests,
    };
  }

  return {
    allowed: true,
    remaining: maxRequests - entry.count,
    resetAt: entry.resetAt,
    limit: maxRequests,
  };
}

// ─── successResponse / errorResponse Helpers ──────────────────────────────────

export function successResponse<T>(
  data: T,
  status: number = 200
): NextResponse {
  return NextResponse.json(
    { success: true, data },
    { status }
  );
}

export function errorResponse(
  message: string,
  status: number = 500,
  extra?: Record<string, unknown>
): NextResponse {
  return NextResponse.json(
    { success: false, message, ...extra },
    { status }
  );
}

// ─── Common Schemas ───────────────────────────────────────────────────────────

export const schedulerBodySchema = z.object({
  type: z.enum(["process_scheduled_posts", "process_campaigns", "check_trends"]),
});
