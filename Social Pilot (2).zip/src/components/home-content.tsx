'use client'

import { SidebarProvider, SidebarInset } from '@/components/ui/sidebar'
import { AppSidebar } from '@/components/app-sidebar'
import { PageHeader } from '@/components/page-header'
import { GlobalSearch } from '@/components/global-search'
import { NotificationBell } from '@/components/notification-bell'
import { useAppStore } from '@/lib/store'
import MobileNav from '@/components/mobile-nav'
import DashboardPage from '@/components/dashboard/dashboard-page'
import PosterPage from '@/components/poster/poster-page'
import CalendarPage from '@/components/calendar/calendar-page'
import CommentsPage from '@/components/comments/comments-page'
import LikerPage from '@/components/liker/liker-page'
import VideoPage from '@/components/video-editor/video-page'
import AIVideoPage from '@/components/ai-video/ai-video-page'
import AccountsPage from '@/components/accounts/accounts-page'
import CompetitorPage from '@/components/competitor/competitor-page'
import CopyrightPage from '@/components/copyright/copyright-page'
import TrendsPage from '@/components/trends/trends-page'
import HashtagsPage from '@/components/hashtags/hashtags-page'
import AIWriterPage from '@/components/ai-writer/ai-writer-page'
import SettingsPage from '@/components/settings/settings-page'

export default function HomeContent() {
  const state = useAppStore()
  const currentPage = state.currentPage

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <DashboardPage />
      case 'poster':
        return <PosterPage />
      case 'calendar':
        return <CalendarPage />
      case 'comments':
        return <CommentsPage />
      case 'liker':
        return <LikerPage />
      case 'video':
        return <VideoPage />
      case 'ai-video':
        return <AIVideoPage />
      case 'accounts':
        return <AccountsPage />
      case 'competitor':
        return <CompetitorPage />
      case 'copyright':
        return <CopyrightPage />
      case 'trends':
        return <TrendsPage />
      case 'hashtags':
        return <HashtagsPage />
      case 'ai-writer':
        return <AIWriterPage />
      case 'settings':
        return <SettingsPage />
      default:
        return <DashboardPage />
    }
  }

  return (
    <>
      <SidebarProvider>
        <AppSidebar />
        <SidebarInset>
          <header className="flex h-14 shrink-0 items-center gap-2 border-b px-4">
            <PageHeader />
            <div className="flex items-center gap-1 ml-auto">
              <NotificationBell />
            </div>
          </header>
          <main className="flex-1 overflow-auto p-4 md:p-6 pb-20 md:pb-6">
            {renderPage()}
          </main>
        </SidebarInset>
      </SidebarProvider>
      <MobileNav />
      <GlobalSearch />
    </>
  )
}
