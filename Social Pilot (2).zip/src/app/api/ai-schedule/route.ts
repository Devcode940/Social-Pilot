import { NextRequest, NextResponse } from "next/server";
import ZAI from "z-ai-web-dev-sdk";

interface AIScheduleRequest {
  platforms: string[];
  content: string;
}

export async function POST(request: NextRequest) {
  try {
    const body: AIScheduleRequest = await request.json();
    const { platforms, content } = body;

    if (!platforms || !Array.isArray(platforms) || platforms.length === 0) {
      return NextResponse.json(
        { message: "At least one platform is required" },
        { status: 400 }
      );
    }

    if (!content || !content.trim()) {
      return NextResponse.json(
        { message: "Content is required" },
        { status: 400 }
      );
    }

    const platformsStr = platforms.join(", ");

    const zai = await ZAI.create();
    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: "system",
          content: `You are a social media scheduling expert who analyzes content and recommends optimal posting times based on platform-specific engagement data and content type.

You must respond with ONLY valid JSON in this exact format (no markdown, no code fences, just raw JSON):
{
  "suggestedTimes": [
    {
      "day": "Monday",
      "time": "9:00 AM",
      "reason": "Brief explanation of why this time is optimal",
      "score": 92
    },
    {
      "day": "Wednesday",
      "time": "12:30 PM",
      "reason": "Brief explanation",
      "score": 87
    },
    {
      "day": "Friday",
      "time": "6:00 PM",
      "reason": "Brief explanation",
      "score": 83
    }
  ],
  "bestDay": "Monday",
  "bestTime": "9:00 AM"
}

Rules:
- Provide exactly 3 suggested posting times
- Score should be between 70-98 (confidence score)
- Times should be realistic and spread across different days
- Consider the content type and platforms when suggesting times
- Keep reasons concise (one sentence)
- Use full day names (Monday, Tuesday, etc.)
- Use 12-hour format with AM/PM`,
        },
        {
          role: "user",
          content: `Suggest optimal posting times for this content across these platforms: ${platformsStr}.\n\nContent: "${content.slice(0, 500)}"`,
        },
      ],
    });

    const rawText = completion.choices?.[0]?.message?.content?.trim() ?? "";

    // Try to parse JSON from the response
    let parsed;
    try {
      // Remove markdown code fences if present
      const cleaned = rawText.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
      parsed = JSON.parse(cleaned);
    } catch {
      // Fallback suggestions if parsing fails
      parsed = {
        suggestedTimes: [
          {
            day: "Tuesday",
            time: "10:00 AM",
            reason: "Tuesday mornings see high engagement for most platforms",
            score: 88,
          },
          {
            day: "Thursday",
            time: "1:00 PM",
            reason: "Midweek lunch hours are peak browsing times",
            score: 84,
          },
          {
            day: "Saturday",
            time: "11:00 AM",
            reason: "Weekend mornings have relaxed, attentive audiences",
            score: 79,
          },
        ],
        bestDay: "Tuesday",
        bestTime: "10:00 AM",
      };
    }

    return NextResponse.json(parsed);
  } catch (error) {
    console.error("POST /api/ai-schedule error:", error);
    return NextResponse.json(
      {
        message:
          error instanceof Error
            ? `Smart scheduling failed: ${error.message}`
            : "Failed to get schedule suggestions. Please try again.",
      },
      { status: 500 }
    );
  }
}
