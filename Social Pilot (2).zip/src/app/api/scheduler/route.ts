import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { tryCatch, validateBody, rateLimit, schedulerBodySchema } from "@/lib/api-helpers";

// ─── Shared scheduler logic ──────────────────────────────────────────────────

async function processScheduledPosts(): Promise<{
  processed: number;
  details: Array<{ postId: string; message: string }>;
}> {
  const now = new Date();
  const details: Array<{ postId: string; message: string }> = [];

  // Find all posts with status "scheduled" where scheduledAt <= now
  const postsToPublish = await db.post.findMany({
    where: {
      status: "scheduled",
      scheduledAt: { lte: now },
    },
  });

  // Get the first user for notification creation
  const user = await db.user.findFirst();

  for (const post of postsToPublish) {
    // Update status to "published" and set publishedAt
    await db.post.update({
      where: { id: post.id },
      data: {
        status: "published",
        publishedAt: now,
      },
    });

    // Create notification for each published post
    if (user) {
      await db.notification.create({
        data: {
          userId: user.id,
          type: "post",
          title: "Post Published",
          message: "Your scheduled post was published",
        },
      });
    }

    details.push({
      postId: post.id,
      message: `Published scheduled post (platforms: ${post.platforms})`,
    });
  }

  return { processed: postsToPublish.length, details };
}

async function processCampaigns(): Promise<{
  processed: number;
  details: Array<{ campaignId: string; message: string }>;
}> {
  const details: Array<{ campaignId: string; message: string }> = [];

  // Find all active campaigns
  const activeCampaigns = await db.campaign.findMany({
    where: { status: "active" },
  });

  // Get the first user for notification creation
  const user = await db.user.findFirst();

  for (const campaign of activeCampaigns) {
    // Simulate progress by incrementing currentCount by a small random amount (1-5)
    const increment = Math.floor(Math.random() * 5) + 1;
    const newCount = campaign.currentCount + increment;

    const isCompleted = newCount >= campaign.targetCount;

    // Update campaign
    await db.campaign.update({
      where: { id: campaign.id },
      data: {
        currentCount: isCompleted ? campaign.targetCount : newCount,
        status: isCompleted ? "completed" : "active",
        ...(isCompleted ? { endedAt: new Date() } : {}),
      },
    });

    // Create notification if campaign completed
    if (isCompleted && user) {
      await db.notification.create({
        data: {
          userId: user.id,
          type: "campaign",
          title: "Campaign Completed",
          message: `"${campaign.name}" has reached its target of ${campaign.targetCount}!`,
        },
      });
    }

    details.push({
      campaignId: campaign.id,
      message: isCompleted
        ? `Campaign "${campaign.name}" completed (${campaign.targetCount}/${campaign.targetCount})`
        : `Campaign "${campaign.name}" progress: ${Math.min(newCount, campaign.targetCount)}/${campaign.targetCount} (+${increment})`,
    });
  }

  return { processed: activeCampaigns.length, details };
}

async function checkTrends(): Promise<{
  processed: number;
  details: Array<{ query: string; message: string }>;
}> {
  const details: Array<{ query: string; message: string }> = [];

  // Find recent trend queries (last 7 days)
  const sevenDaysAgo = new Date();
  sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

  const recentTrends = await db.trendResult.findMany({
    where: {
      createdAt: { gte: sevenDaysAgo },
    },
    orderBy: { createdAt: "desc" },
    take: 5,
  });

  // Get the first user for notification creation
  const user = await db.user.findFirst();

  for (const trend of recentTrends) {
    // Check if there are significant changes by comparing results
    const existingResults = trend.results;
    const hasResults = existingResults && existingResults.length > 0;

    if (hasResults && user) {
      // In a real implementation, this would re-query the trend API and compare results
      // For now, we simulate by checking if the trend has been queried recently
      const hoursSinceQuery =
        (Date.now() - trend.createdAt.getTime()) / (1000 * 60 * 60);

      if (hoursSinceQuery > 24) {
        // Create notification for trends that haven't been checked in over 24 hours
        await db.notification.create({
          data: {
            userId: user.id,
            type: "trend",
            title: "Trend Update Available",
            message: `New data may be available for trend: "${trend.query}"`,
          },
        });

        details.push({
          query: trend.query,
          message: `Trend "${trend.query}" hasn't been refreshed in ${Math.round(hoursSinceQuery)} hours — update recommended`,
        });
      } else {
        details.push({
          query: trend.query,
          message: `Trend "${trend.query}" is recent (${Math.round(hoursSinceQuery)}h ago)`,
        });
      }
    } else if (hasResults) {
      details.push({
        query: trend.query,
        message: `Trend "${trend.query}" checked — no significant changes detected`,
      });
    }
  }

  return { processed: recentTrends.length, details };
}

// ─── Core scheduler runner ───────────────────────────────────────────────────

async function runScheduler(
  type: "process_scheduled_posts" | "process_campaigns" | "check_trends"
): Promise<{
  processed: number;
  details: Array<{ id: string; message: string }>;
}> {
  let result: {
    processed: number;
    details: Array<{ postId: string; message: string } | { campaignId: string; message: string } | { query: string; message: string }>;
  };

  switch (type) {
    case "process_scheduled_posts":
      result = await processScheduledPosts();
      break;
    case "process_campaigns":
      result = await processCampaigns();
      break;
    case "check_trends":
      result = await checkTrends();
      break;
  }

  // Save result to ScheduledJob table
  await db.scheduledJob.create({
    data: {
      type,
      payload: JSON.stringify({ triggeredBy: "api" }),
      runAt: new Date(),
      status: "completed",
      result: JSON.stringify({
        processed: result.processed,
        details: result.details,
      }),
    },
  });

  // Normalize detail IDs
  const normalizedDetails = result.details.map((d) => ({
    id:
      "postId" in d
        ? d.postId
        : "campaignId" in d
          ? d.campaignId
          : ("query" in d ? d.query : ""),
    message: d.message,
  }));

  return { processed: result.processed, details: normalizedDetails };
}

// ─── POST Handler ─────────────────────────────────────────────────────────────

export const POST = tryCatch(async (request: NextRequest): Promise<NextResponse> => {
  // Rate limiting
  const limiter = rateLimit(request, { maxRequests: 30, windowSeconds: 60 });
  if (!limiter.allowed) {
    return NextResponse.json(
      {
        success: false,
        message: "Rate limit exceeded. Please try again later.",
        resetAt: limiter.resetAt,
      },
      {
        status: 429,
        headers: {
          "Retry-After": String(Math.ceil((limiter.resetAt - Date.now()) / 1000)),
        },
      }
    );
  }

  // Validate request body
  const validation = await validateBody(request, schedulerBodySchema);
  if (!validation.success) return validation.response;

  const { type } = validation.data;

  const result = await runScheduler(type);

  return NextResponse.json({
    success: true,
    type,
    ...result,
    timestamp: new Date().toISOString(),
  });
});

// ─── GET Handler (status / info) ─────────────────────────────────────────────

export async function GET() {
  try {
    // Return info about the scheduler
    const recentJobs = await db.scheduledJob.findMany({
      orderBy: { createdAt: "desc" },
      take: 10,
    });

    const jobCounts = await db.scheduledJob.groupBy({
      by: ["type"],
      _count: { id: true },
    });

    const statusCounts = await db.scheduledJob.groupBy({
      by: ["status"],
      _count: { id: true },
    });

    return NextResponse.json({
      scheduler: "active",
      availableJobs: ["process_scheduled_posts", "process_campaigns", "check_trends"],
      recentJobs: recentJobs.map((j) => ({
        id: j.id,
        type: j.type,
        status: j.status,
        runAt: j.runAt,
        createdAt: j.createdAt,
      })),
      stats: {
        totalByType: jobCounts.map((j) => ({ type: j.type, count: j._count.id })),
        totalByStatus: statusCounts.map((j) => ({ status: j.status, count: j._count.id })),
      },
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("GET /api/scheduler error:", error);
    return NextResponse.json(
      { success: false, message: "Failed to fetch scheduler status" },
      { status: 500 }
    );
  }
}
