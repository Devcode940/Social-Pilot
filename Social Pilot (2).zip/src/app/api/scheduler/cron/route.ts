import { NextResponse } from "next/server";
import { db } from "@/lib/db";

// ─── Cron Endpoint ───────────────────────────────────────────────────────────
// This GET endpoint can be called by an external cron service (e.g., cron-job.org).
// It processes all scheduled job types and returns a simple status response.

export const runtime = "nodejs";

export async function GET() {
  try {
    const now = new Date();
    const allDetails: Array<{ type: string; processed: number; message: string }> = [];

    // ── 1. Process scheduled posts ──
    const postsToPublish = await db.post.findMany({
      where: {
        status: "scheduled",
        scheduledAt: { lte: now },
      },
    });

    const user = await db.user.findFirst();

    for (const post of postsToPublish) {
      await db.post.update({
        where: { id: post.id },
        data: { status: "published", publishedAt: now },
      });

      if (user) {
        await db.notification.create({
          data: {
            userId: user.id,
            type: "post",
            title: "Post Published",
            message: "Your scheduled post was published",
          },
        });
      }
    }

    if (postsToPublish.length > 0) {
      await db.scheduledJob.create({
        data: {
          type: "process_scheduled_posts",
          payload: JSON.stringify({ triggeredBy: "cron" }),
          runAt: now,
          status: "completed",
          result: JSON.stringify({ published: postsToPublish.length }),
        },
      });
    }

    allDetails.push({
      type: "process_scheduled_posts",
      processed: postsToPublish.length,
      message: `Published ${postsToPublish.length} scheduled post(s)`,
    });

    // ── 2. Process campaigns ──
    const activeCampaigns = await db.campaign.findMany({
      where: { status: "active" },
    });

    let campaignsCompleted = 0;

    for (const campaign of activeCampaigns) {
      const increment = Math.floor(Math.random() * 5) + 1;
      const newCount = campaign.currentCount + increment;
      const isCompleted = newCount >= campaign.targetCount;

      await db.campaign.update({
        where: { id: campaign.id },
        data: {
          currentCount: isCompleted ? campaign.targetCount : newCount,
          status: isCompleted ? "completed" : "active",
          ...(isCompleted ? { endedAt: now } : {}),
        },
      });

      if (isCompleted) {
        campaignsCompleted++;
        if (user) {
          await db.notification.create({
            data: {
              userId: user.id,
              type: "campaign",
              title: "Campaign Completed",
              message: `"${campaign.name}" has reached its target of ${campaign.targetCount}!`,
            },
          });
        }
      }
    }

    if (activeCampaigns.length > 0) {
      await db.scheduledJob.create({
        data: {
          type: "process_campaigns",
          payload: JSON.stringify({ triggeredBy: "cron" }),
          runAt: now,
          status: "completed",
          result: JSON.stringify({
            processed: activeCampaigns.length,
            completed: campaignsCompleted,
          }),
        },
      });
    }

    allDetails.push({
      type: "process_campaigns",
      processed: activeCampaigns.length,
      message: `Updated ${activeCampaigns.length} campaign(s), ${campaignsCompleted} completed`,
    });

    // ── 3. Check trends ──
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

    const recentTrends = await db.trendResult.findMany({
      where: { createdAt: { gte: sevenDaysAgo } },
      orderBy: { createdAt: "desc" },
      take: 5,
    });

    let trendNotifications = 0;

    for (const trend of recentTrends) {
      const hoursSinceQuery =
        (Date.now() - trend.createdAt.getTime()) / (1000 * 60 * 60);

      if (hoursSinceQuery > 24 && user) {
        await db.notification.create({
          data: {
            userId: user.id,
            type: "trend",
            title: "Trend Update Available",
            message: `New data may be available for trend: "${trend.query}"`,
          },
        });
        trendNotifications++;
      }
    }

    if (recentTrends.length > 0) {
      await db.scheduledJob.create({
        data: {
          type: "check_trends",
          payload: JSON.stringify({ triggeredBy: "cron" }),
          runAt: now,
          status: "completed",
          result: JSON.stringify({
            checked: recentTrends.length,
            notifications: trendNotifications,
          }),
        },
      });
    }

    allDetails.push({
      type: "check_trends",
      processed: recentTrends.length,
      message: `Checked ${recentTrends.length} trend(s), ${trendNotifications} notification(s) created`,
    });

    // ── Build response ──
    const totalProcessed =
      postsToPublish.length + activeCampaigns.length + recentTrends.length;

    return NextResponse.json({
      success: true,
      message: `Scheduler cron completed successfully`,
      timestamp: now.toISOString(),
      totalProcessed,
      details: allDetails,
    });
  } catch (error) {
    console.error("[Scheduler Cron Error]", error);

    // Log the failure
    try {
      await db.scheduledJob.create({
        data: {
          type: "cron_all",
          payload: JSON.stringify({ triggeredBy: "cron" }),
          runAt: new Date(),
          status: "failed",
          result: JSON.stringify({
            error: error instanceof Error ? error.message : "Unknown error",
          }),
        },
      });
    } catch {
      // Ignore DB errors in error handler
    }

    return NextResponse.json(
      {
        success: false,
        message: "Scheduler cron failed",
        error: error instanceof Error ? error.message : "Internal error",
        timestamp: new Date().toISOString(),
      },
      { status: 500 }
    );
  }
}
