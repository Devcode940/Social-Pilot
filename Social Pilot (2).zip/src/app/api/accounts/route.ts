import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  try {
    const accounts = await db.socialAccount.findMany({
      include: {
        user: true,
      },
      orderBy: { connectedAt: "desc" },
    });

    return NextResponse.json(accounts);
  } catch (error) {
    console.error("GET /api/accounts error:", error);
    return NextResponse.json(
      { message: "Failed to fetch accounts" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { platform, username, displayName, avatar } = body;

    // Find the first user (demo user)
    const user = await db.user.findFirst();
    if (!user) {
      return NextResponse.json(
        { message: "No user found. Please seed the database first." },
        { status: 400 }
      );
    }

    const account = await db.socialAccount.create({
      data: {
        userId: user.id,
        platform,
        username,
        displayName: displayName || null,
        avatar: avatar || null,
      },
    });

    return NextResponse.json(account, { status: 201 });
  } catch (error) {
    console.error("POST /api/accounts error:", error);
    return NextResponse.json(
      { message: "Failed to connect account" },
      { status: 500 }
    );
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, isActive, autoPost } = body;

    if (!id) {
      return NextResponse.json(
        { message: "Account id is required" },
        { status: 400 }
      );
    }

    const data: Record<string, unknown> = {};
    if (isActive !== undefined) data.isActive = isActive;
    if (autoPost !== undefined) data.autoPost = autoPost;

    const account = await db.socialAccount.update({
      where: { id },
      data,
    });

    return NextResponse.json(account);
  } catch (error) {
    console.error("PUT /api/accounts error:", error);
    return NextResponse.json(
      { message: "Failed to update account" },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const urlId = searchParams.get("id");

    let id = urlId;
    if (!id) {
      try {
        const body = await request.json();
        id = body.id;
      } catch {
        // no body, that's fine
      }
    }

    if (!id) {
      return NextResponse.json(
        { message: "Account id is required" },
        { status: 400 }
      );
    }

    await db.socialAccount.delete({
      where: { id },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE /api/accounts error:", error);
    return NextResponse.json(
      { message: "Failed to disconnect account" },
      { status: 500 }
    );
  }
}
