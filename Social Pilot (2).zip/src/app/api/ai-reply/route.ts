import { NextRequest, NextResponse } from "next/server";
import ZAI from "z-ai-web-dev-sdk";

interface AIReplyRequest {
  commentId: string;
  commentContent: string;
  tone?: string;
}

export async function POST(request: NextRequest) {
  try {
    const body: AIReplyRequest = await request.json();
    const { commentContent, tone = "professional and friendly" } = body;

    if (!commentContent) {
      return NextResponse.json(
        { message: "commentContent is required" },
        { status: 400 }
      );
    }

    const zai = await ZAI.create();
    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: "system",
          content: `You are a social media community manager who writes excellent, concise replies to comments. Your tone is ${tone}.

Rules:
- Keep the reply concise (1-3 sentences max)
- Match the sentiment of the original comment
- If the comment is a question, answer it helpfully
- If the comment is negative, be empathetic and professional
- If the comment is positive, show gratitude
- Do NOT use hashtags unless the original comment used them
- Do NOT include quotation marks around your reply
- Write ONLY the reply text, nothing else`,
        },
        {
          role: "user",
          content: `Write a reply to this social media comment: "${commentContent}"`,
        },
      ],
    });

    const suggestedReply =
      completion.choices?.[0]?.message?.content?.trim() ?? "";

    return NextResponse.json({ suggestedReply });
  } catch (error) {
    console.error("POST /api/ai-reply error:", error);
    return NextResponse.json(
      {
        message:
          error instanceof Error
            ? `AI reply generation failed: ${error.message}`
            : "Failed to generate AI reply. Please try again.",
      },
      { status: 500 }
    );
  }
}
