import { NextRequest, NextResponse } from "next/server";
import ZAI from "z-ai-web-dev-sdk";

interface AIWriterRequest {
  topic: string;
  contentType: string;
  tone: string;
  platforms: string[];
  options?: {
    audience?: string;
    includeEmojis?: boolean;
    includeHashtags?: boolean;
    includeCTA?: boolean;
    length?: string;
    language?: string;
  };
}

export async function POST(request: NextRequest) {
  try {
    const body: AIWriterRequest = await request.json();
    const {
      topic,
      contentType,
      tone,
      platforms,
      options = {},
    } = body;

    const {
      audience = "general",
      includeEmojis = true,
      includeHashtags = true,
      includeCTA = true,
      length = "medium",
      language = "English",
    } = options;

    const platformsStr = Array.isArray(platforms)
      ? platforms.join(", ")
      : platforms;

    const systemPrompt = `You are a world-class social media content expert and copywriter. You create engaging, high-performing content that drives engagement and growth.

Your task is to generate exactly 3 unique variations of social media content based on the user's request.

Content parameters:
- Topic: ${topic}
- Content Type: ${contentType} (e.g., post, caption, tweet, story, thread, ad copy)
- Tone: ${tone}
- Target Platforms: ${platformsStr}
- Target Audience: ${audience}
- Length: ${length}
- Language: ${language}
- Include Emojis: ${includeEmojis ? "Yes" : "No"}
- Include Hashtags: ${includeHashtags ? "Yes" : "No"}
- Include Call-to-Action: ${includeCTA ? "Yes" : "No"}

CRITICAL FORMATTING RULES:
1. Generate exactly 3 distinct variations.
2. Separate each variation with exactly this delimiter on its own line: ---VARIATION---
3. Each variation should have a different angle, hook, or approach while staying on topic.
4. Do NOT include any labels like "Variation 1:" or "Option A:" - start directly with the content.
5. Make each variation optimized for the specified platforms.
6. Ensure proper use of line breaks and formatting for social media readability.`;

    const zai = await ZAI.create();
    const completion = await zai.chat.completions.create({
      messages: [
        { role: "system", content: systemPrompt },
        {
          role: "user",
          content: `Write 3 social media ${contentType} variations about: "${topic}". Tone: ${tone}. Platforms: ${platformsStr}.`,
        },
      ],
    });

    const aiText = completion.choices?.[0]?.message?.content ?? "";

    // Parse the response into 3 variations using the delimiter
    const rawVariations = aiText
      .split("---VARIATION---")
      .map((v) => v.trim())
      .filter((v) => v.length > 0);

    let variations: { text: string; wordCount: number; charCount: number }[];

    if (rawVariations.length >= 2) {
      variations = rawVariations.slice(0, 3).map((text) => ({
        text,
        wordCount: text.split(/\s+/).filter(Boolean).length,
        charCount: text.length,
      }));
    } else {
      // Fallback: split by double newlines if delimiter wasn't used
      const fallbackVariations = aiText
        .split(/\n\s*\n/)
        .map((v) => v.trim())
        .filter((v) => v.length > 10);

      if (fallbackVariations.length >= 2) {
        variations = fallbackVariations.slice(0, 3).map((text) => ({
          text,
          wordCount: text.split(/\s+/).filter(Boolean).length,
          charCount: text.length,
        }));
      } else {
        // Last resort: return the whole text as a single variation
        variations = [
          {
            text: aiText.trim(),
            wordCount: aiText.trim().split(/\s+/).filter(Boolean).length,
            charCount: aiText.trim().length,
          },
        ];
      }
    }

    return NextResponse.json({ variations });
  } catch (error) {
    console.error("POST /api/ai-writer error:", error);
    return NextResponse.json(
      {
        message:
          error instanceof Error
            ? `AI content generation failed: ${error.message}`
            : "AI content generation failed. Please try again.",
      },
      { status: 500 }
    );
  }
}
