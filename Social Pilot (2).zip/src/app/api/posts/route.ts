import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get("status");

    const posts = await db.post.findMany({
      where: status ? { status } : undefined,
      orderBy: { createdAt: "desc" },
      include: {
        account: true,
        tags: true,
      },
    });

    return NextResponse.json(posts);
  } catch (error) {
    console.error("GET /api/posts error:", error);
    return NextResponse.json(
      { message: "Failed to fetch posts" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { platforms, content, mediaUrl, mediaType, status, scheduledAt } = body;

    // Find the first user (demo user)
    const user = await db.user.findFirst();
    if (!user) {
      return NextResponse.json(
        { message: "No user found. Please seed the database first." },
        { status: 400 }
      );
    }

    const post = await db.post.create({
      data: {
        userId: user.id,
        platforms,
        content,
        mediaUrl: mediaUrl || null,
        mediaType: mediaType || null,
        status: status || "draft",
        scheduledAt: scheduledAt ? new Date(scheduledAt) : null,
      },
      include: {
        account: true,
        tags: true,
      },
    });

    return NextResponse.json(post, { status: 201 });
  } catch (error) {
    console.error("POST /api/posts error:", error);
    return NextResponse.json(
      { message: "Failed to create post" },
      { status: 500 }
    );
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, content, platforms, status, scheduledAt } = body;

    if (!id) {
      return NextResponse.json(
        { message: "Post id is required" },
        { status: 400 }
      );
    }

    const data: Record<string, unknown> = {};
    if (content !== undefined) data.content = content;
    if (platforms !== undefined) data.platforms = platforms;
    if (status !== undefined) data.status = status;
    if (scheduledAt !== undefined) {
      data.scheduledAt = scheduledAt ? new Date(scheduledAt) : null;
    }

    const post = await db.post.update({
      where: { id },
      data,
      include: {
        account: true,
        tags: true,
      },
    });

    return NextResponse.json(post);
  } catch (error) {
    console.error("PUT /api/posts error:", error);
    return NextResponse.json(
      { message: "Failed to update post" },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json(
        { message: "Post id is required" },
        { status: 400 }
      );
    }

    await db.post.delete({
      where: { id },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE /api/posts error:", error);
    return NextResponse.json(
      { message: "Failed to delete post" },
      { status: 500 }
    );
  }
}
