import { NextRequest, NextResponse } from "next/server";
import ZAI from "z-ai-web-dev-sdk";
import { db } from "@/lib/db";

interface TrendsRequest {
  query: string;
  platform?: string;
  timeRange?: string;
}

function deduceCategory(snippet: string): string {
  const lower = snippet.toLowerCase();
  if (
    lower.includes("ai") ||
    lower.includes("artificial intelligence") ||
    lower.includes("machine learning")
  )
    return "AI & Technology";
  if (lower.includes("marketing") || lower.includes("brand") || lower.includes("advertis"))
    return "Marketing";
  if (lower.includes("video") || lower.includes("reel") || lower.includes("short"))
    return "Video Content";
  if (lower.includes("hashtag") || lower.includes("trending"))
    return "Trending";
  if (
    lower.includes("instagram") ||
    lower.includes("tiktok") ||
    lower.includes("youtube")
  )
    return "Social Platforms";
  if (lower.includes("engagement") || lower.includes("growth") || lower.includes("follower"))
    return "Growth & Engagement";
  if (lower.includes("influencer") || lower.includes("creator"))
    return "Creator Economy";
  return "General";
}

function processSearchResults(
  results: unknown[]
): Array<{
  title: string;
  snippet: string;
  source: string;
  url: string;
  category: string;
}> {
  if (!Array.isArray(results)) return [];

  return results
    .map((item: unknown) => {
      const r = item as Record<string, unknown>;
      return {
        title: (r.name as string) || "",
        snippet: (r.snippet as string) || "",
        source: (r.host_name as string) || "",
        url: (r.url as string) || "",
        category: deduceCategory((r.snippet as string) || ""),
      };
    })
    .filter((r) => r.title && r.snippet);
}

export async function POST(request: NextRequest) {
  try {
    const body: TrendsRequest = await request.json();
    const { query, platform, timeRange } = body;

    const zai = await ZAI.create();

    // 1. Search for general social media trends
    const timeSuffix = timeRange ? ` ${timeRange}` : "";
    const trendsSearch = await zai.functions.invoke("web_search", {
      query: `${query} social media trends 2026${timeSuffix}`,
      num: 10,
    });
    const trends = processSearchResults(
      Array.isArray(trendsSearch) ? trendsSearch : []
    );

    // 2. Search for viral content
    const viralQuery = platform
      ? `${query} viral content ${platform}${timeSuffix}`
      : `${query} viral content social media${timeSuffix}`;
    const viralSearch = await zai.functions.invoke("web_search", {
      query: viralQuery,
      num: 10,
    });
    const viralContent = processSearchResults(
      Array.isArray(viralSearch) ? viralSearch : []
    );

    // 3. Search for trending hashtags (if platform includes instagram or tiktok)
    let hashtags: Array<{
      title: string;
      snippet: string;
      source: string;
      url: string;
      category: string;
    }> = [];

    const platformLower = (platform || "").toLowerCase();
    if (
      platformLower.includes("instagram") ||
      platformLower.includes("tiktok")
    ) {
      const hashtagSearch = await zai.functions.invoke("web_search", {
        query: `${query} trending hashtags 2026${timeSuffix}`,
        num: 10,
      });
      hashtags = processSearchResults(
        Array.isArray(hashtagSearch) ? hashtagSearch : []
      );
    }

    // 4. Save results to TrendResult model in DB
    await db.trendResult.create({
      data: {
        query,
        platform: platform || null,
        results: JSON.stringify({
          trends,
          viralContent,
          hashtags,
          searchedAt: new Date().toISOString(),
        }),
      },
    });

    return NextResponse.json({
      trends,
      viralContent,
      hashtags,
      saved: true,
    });
  } catch (error) {
    console.error("POST /api/trends error:", error);
    return NextResponse.json(
      {
        message:
          error instanceof Error
            ? `Trend search failed: ${error.message}`
            : "Failed to search trends. Please try again.",
      },
      { status: 500 }
    );
  }
}
