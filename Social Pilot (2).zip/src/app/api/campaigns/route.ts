import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  try {
    const campaigns = await db.campaign.findMany({
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json(campaigns);
  } catch (error) {
    console.error("GET /api/campaigns error:", error);
    return NextResponse.json(
      { message: "Failed to fetch campaigns" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, type, platforms, targetCount, rules } = body;

    const campaign = await db.campaign.create({
      data: {
        name,
        type,
        platforms,
        targetCount: targetCount || 100,
        rules: rules ? JSON.stringify(rules) : null,
      },
    });

    return NextResponse.json(campaign, { status: 201 });
  } catch (error) {
    console.error("POST /api/campaigns error:", error);
    return NextResponse.json(
      { message: "Failed to create campaign" },
      { status: 500 }
    );
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, status, currentCount } = body;

    const data: Record<string, unknown> = {};
    if (status !== undefined) data.status = status;
    if (currentCount !== undefined) data.currentCount = currentCount;

    const campaign = await db.campaign.update({
      where: { id },
      data,
    });

    return NextResponse.json(campaign);
  } catch (error) {
    console.error("PATCH /api/campaigns error:", error);
    return NextResponse.json(
      { message: "Failed to update campaign" },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json(
        { message: "Campaign id is required" },
        { status: 400 }
      );
    }

    await db.campaign.delete({
      where: { id },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE /api/campaigns error:", error);
    return NextResponse.json(
      { message: "Failed to delete campaign" },
      { status: 500 }
    );
  }
}
