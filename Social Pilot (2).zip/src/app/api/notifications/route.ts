import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const unreadOnly = searchParams.get("unreadOnly") === "true";

    const user = await db.user.findFirst();
    if (!user) {
      return NextResponse.json({ message: "No user found" }, { status: 404 });
    }

    const notifications = await db.notification.findMany({
      where: {
        userId: user.id,
        ...(unreadOnly && { read: false }),
      },
      orderBy: { createdAt: "desc" },
      take: unreadOnly ? 50 : 20,
    });

    const unreadCount = await db.notification.count({
      where: { userId: user.id, read: false },
    });

    return NextResponse.json({ notifications, unreadCount });
  } catch (error) {
    console.error("GET /api/notifications error:", error);
    return NextResponse.json(
      { message: "Failed to fetch notifications" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { type, title, message } = body;

    const user = await db.user.findFirst();
    if (!user) {
      return NextResponse.json({ message: "No user found" }, { status: 404 });
    }

    const notification = await db.notification.create({
      data: {
        userId: user.id,
        type: type || "system",
        title: title || "Notification",
        message: message || "",
      },
    });

    return NextResponse.json({ notification }, { status: 201 });
  } catch (error) {
    console.error("POST /api/notifications error:", error);
    return NextResponse.json(
      { message: "Failed to create notification" },
      { status: 500 }
    );
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();
    const { ids, all } = body;

    const user = await db.user.findFirst();
    if (!user) {
      return NextResponse.json({ message: "No user found" }, { status: 404 });
    }

    if (all) {
      await db.notification.updateMany({
        where: { userId: user.id, read: false },
        data: { read: true },
      });
      return NextResponse.json({ success: true, message: "All notifications marked as read" });
    }

    if (ids && Array.isArray(ids) && ids.length > 0) {
      await db.notification.updateMany({
        where: { id: { in: ids } },
        data: { read: true },
      });
      return NextResponse.json({ success: true, message: `${ids.length} notifications marked as read` });
    }

    return NextResponse.json({ message: "Provide ids or all" }, { status: 400 });
  } catch (error) {
    console.error("PATCH /api/notifications error:", error);
    return NextResponse.json(
      { message: "Failed to update notifications" },
      { status: 500 }
    );
  }
}
