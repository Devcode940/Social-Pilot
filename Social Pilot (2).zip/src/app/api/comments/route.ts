import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import ZAI from "z-ai-web-dev-sdk";

// Simple in-memory cache for sentiment results
const sentimentCache = new Map<string, string>();

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const isRead = searchParams.get("isRead");
    const action = searchParams.get("action");

    const comments = await db.comment.findMany({
      where: isRead !== null ? { isRead: isRead === "true" } : undefined,
      orderBy: { createdAt: "desc" },
      include: {
        post: {
          select: {
            id: true,
            content: true,
            platforms: true,
          },
        },
      },
    });

    // If action=analyze_sentiment, analyze comments without sentiment
    if (action === "analyze_sentiment") {
      const commentsWithoutSentiment = comments.filter((c) => !c.sentiment && !c.archived);

      if (commentsWithoutSentiment.length > 0) {
        // Batch analyze (max 10 at a time)
        const batchSize = 10;
        for (let i = 0; i < commentsWithoutSentiment.length; i += batchSize) {
          const batch = commentsWithoutSentiment.slice(i, i + batchSize);

          for (const comment of batch) {
            // Check cache first
            const cached = sentimentCache.get(comment.id);
            if (cached) {
              await db.comment.update({
                where: { id: comment.id },
                data: { sentiment: cached },
              });
              continue;
            }

            try {
              const sentiment = await analyzeCommentSentiment(comment.content);
              sentimentCache.set(comment.id, sentiment);

              await db.comment.update({
                where: { id: comment.id },
                data: { sentiment },
              });
            } catch (err) {
              console.error(
                `Failed to analyze sentiment for comment ${comment.id}:`,
                err
              );
            }
          }
        }

        // Re-fetch comments with updated sentiments
        const updatedComments = await db.comment.findMany({
          where: isRead !== null ? { isRead: isRead === "true" } : undefined,
          orderBy: { createdAt: "desc" },
          include: {
            post: {
              select: {
                id: true,
                content: true,
                platforms: true,
              },
            },
          },
        });

        return NextResponse.json(updatedComments);
      }
    }

    return NextResponse.json(comments);
  } catch (error) {
    console.error("GET /api/comments error:", error);
    return NextResponse.json(
      { message: "Failed to fetch comments" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { postId, author, content, platform } = body;

    if (!author || !content || !platform) {
      return NextResponse.json(
        { message: "author, content, and platform are required" },
        { status: 400 }
      );
    }

    // Find user's first post or use provided postId
    let targetPostId = postId;
    if (!targetPostId) {
      const firstPost = await db.post.findFirst({
        orderBy: { createdAt: "desc" },
      });
      targetPostId = firstPost?.id;
    }

    if (!targetPostId) {
      return NextResponse.json(
        { message: "No post found to attach comment to" },
        { status: 400 }
      );
    }

    const comment = await db.comment.create({
      data: {
        postId: targetPostId,
        author,
        content,
        platform,
      },
    });

    return NextResponse.json(comment, { status: 201 });
  } catch (error) {
    console.error("POST /api/comments error:", error);
    return NextResponse.json(
      { message: "Failed to create comment" },
      { status: 500 }
    );
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, isRead, isReplied, reply, sentiment, archived } = body;

    const data: Record<string, unknown> = {};
    if (isRead !== undefined) data.isRead = isRead;
    if (isReplied !== undefined) data.isReplied = isReplied;
    if (reply !== undefined) data.reply = reply;
    if (sentiment !== undefined) data.sentiment = sentiment;
    if (archived !== undefined) data.archived = archived;

    const comment = await db.comment.update({
      where: { id },
      data,
    });

    return NextResponse.json(comment);
  } catch (error) {
    console.error("PATCH /api/comments error:", error);
    return NextResponse.json(
      { message: "Failed to update comment" },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json(
        { message: "Comment id is required" },
        { status: 400 }
      );
    }

    await db.comment.delete({
      where: { id },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE /api/comments error:", error);
    return NextResponse.json(
      { message: "Failed to delete comment" },
      { status: 500 }
    );
  }
}

// ── Helper: AI Sentiment Analysis ──

async function analyzeCommentSentiment(
  content: string
): Promise<"positive" | "negative" | "neutral" | "question"> {
  // Check cache
  const cacheKey = `sentiment:${content.slice(0, 200)}`;
  const cached = sentimentCache.get(cacheKey);
  if (cached) return cached as "positive" | "negative" | "neutral" | "question";

  try {
    const zai = await ZAI.create();
    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: "system",
          content: `You are a sentiment analysis engine for social media comments. Classify each comment into exactly ONE of these categories:
- "positive": praise, compliments, gratitude, excitement, love, support
- "negative": complaints, criticism, frustration, anger, disappointment
- "question": the comment asks a question or seeks information (even if the tone is positive or negative)
- "question": if the comment is primarily a question, regardless of tone

Respond with ONLY ONE word: positive, negative, neutral, or question. Nothing else.`,
        },
        {
          role: "user",
          content: `Classify this comment: "${content}"`,
        },
      ],
    });

    const result =
      completion.choices?.[0]?.message?.content?.trim().toLowerCase() ?? "neutral";

    let sentiment: "positive" | "negative" | "neutral" | "question" = "neutral";
    if (result.includes("positive")) sentiment = "positive";
    else if (result.includes("negative")) sentiment = "negative";
    else if (result.includes("question")) sentiment = "question";

    sentimentCache.set(cacheKey, sentiment);
    return sentiment;
  } catch (error) {
    console.error("Sentiment analysis failed:", error);
    return "neutral";
  }
}
