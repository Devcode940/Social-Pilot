import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  try {
    const user = await db.user.findFirst();
    if (!user) {
      return NextResponse.json({ message: "No user found" }, { status: 404 });
    }

    const settings = await db.userSettings.findUnique({
      where: { userId: user.id },
    });

    const apiKeys = await db.apiKey.findMany({
      where: { userId: user.id },
      select: { id: true, label: true, key: true, createdAt: true },
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json({
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        avatar: user.avatar,
        bio: user.bio,
        timezone: user.timezone,
      },
      settings: settings || {
        emailNotifications: true,
        pushNotifications: true,
        postPublishedNotify: true,
        commentAlerts: true,
        campaignCompletion: true,
        weeklyAnalyticsDigest: true,
        trendAlerts: false,
        theme: "system",
        compactMode: false,
        sidebarDefaultExpanded: true,
      },
      apiKeys,
    });
  } catch (error) {
    console.error("GET /api/settings error:", error);
    return NextResponse.json(
      { message: "Failed to fetch settings" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { section, ...data } = body;

    const user = await db.user.findFirst();
    if (!user) {
      return NextResponse.json({ message: "No user found" }, { status: 404 });
    }

    // Update profile
    if (section === "profile") {
      const updatedUser = await db.user.update({
        where: { id: user.id },
        data: {
          ...(data.name !== undefined && { name: data.name }),
          ...(data.bio !== undefined && { bio: data.bio }),
          ...(data.timezone !== undefined && { timezone: data.timezone }),
        },
        select: { id: true, email: true, name: true, avatar: true, bio: true, timezone: true },
      });
      return NextResponse.json({ user: updatedUser });
    }

    // Update notification preferences
    if (section === "notifications") {
      const settings = await db.userSettings.upsert({
        where: { userId: user.id },
        create: {
          userId: user.id,
          emailNotifications: data.emailNotifications ?? true,
          pushNotifications: data.pushNotifications ?? true,
          postPublishedNotify: data.postPublishedNotify ?? true,
          commentAlerts: data.commentAlerts ?? true,
          campaignCompletion: data.campaignCompletion ?? true,
          weeklyAnalyticsDigest: data.weeklyAnalyticsDigest ?? true,
          trendAlerts: data.trendAlerts ?? false,
        },
        update: {
          ...(data.emailNotifications !== undefined && { emailNotifications: data.emailNotifications }),
          ...(data.pushNotifications !== undefined && { pushNotifications: data.pushNotifications }),
          ...(data.postPublishedNotify !== undefined && { postPublishedNotify: data.postPublishedNotify }),
          ...(data.commentAlerts !== undefined && { commentAlerts: data.commentAlerts }),
          ...(data.campaignCompletion !== undefined && { campaignCompletion: data.campaignCompletion }),
          ...(data.weeklyAnalyticsDigest !== undefined && { weeklyAnalyticsDigest: data.weeklyAnalyticsDigest }),
          ...(data.trendAlerts !== undefined && { trendAlerts: data.trendAlerts }),
        },
      });
      return NextResponse.json({ settings });
    }

    // Update appearance settings
    if (section === "appearance") {
      const settings = await db.userSettings.upsert({
        where: { userId: user.id },
        create: {
          userId: user.id,
          theme: data.theme ?? "system",
          compactMode: data.compactMode ?? false,
          sidebarDefaultExpanded: data.sidebarDefaultExpanded ?? true,
        },
        update: {
          ...(data.theme !== undefined && { theme: data.theme }),
          ...(data.compactMode !== undefined && { compactMode: data.compactMode }),
          ...(data.sidebarDefaultExpanded !== undefined && { sidebarDefaultExpanded: data.sidebarDefaultExpanded }),
        },
      });
      return NextResponse.json({ settings });
    }

    // Add API key
    if (section === "apiKey") {
      const { label, key } = data;
      if (!label || !key) {
        return NextResponse.json({ message: "Label and key are required" }, { status: 400 });
      }
      const apiKey = await db.apiKey.create({
        data: { userId: user.id, label, key },
      });
      return NextResponse.json({ apiKey }, { status: 201 });
    }

    // Delete API key
    if (section === "deleteApiKey") {
      const { id } = data;
      if (!id) {
        return NextResponse.json({ message: "Key id is required" }, { status: 400 });
      }
      await db.apiKey.delete({ where: { id } });
      return NextResponse.json({ success: true });
    }

    return NextResponse.json({ message: "Invalid section" }, { status: 400 });
  } catch (error) {
    console.error("POST /api/settings error:", error);
    return NextResponse.json(
      { message: "Failed to update settings" },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const action = searchParams.get("action");

    if (action === "deleteAccount") {
      // In a real app this would delete the user account
      return NextResponse.json({ success: true, message: "Account deletion requested" });
    }

    if (action === "clearData") {
      const user = await db.user.findFirst();
      if (!user) {
        return NextResponse.json({ message: "No user found" }, { status: 404 });
      }
      await db.comment.deleteMany();
      await db.post.deleteMany();
      await db.campaign.deleteMany();
      await db.notification.deleteMany({ where: { userId: user.id } });
      return NextResponse.json({ success: true, message: "All data cleared" });
    }

    return NextResponse.json({ message: "Invalid action" }, { status: 400 });
  } catch (error) {
    console.error("DELETE /api/settings error:", error);
    return NextResponse.json(
      { message: "Failed to perform action" },
      { status: 500 }
    );
  }
}
