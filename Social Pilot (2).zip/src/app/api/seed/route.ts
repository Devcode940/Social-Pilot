import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function POST() {
  try {
    // Check if seed data already exists
    const existingUser = await db.user.findUnique({
      where: { email: "demo@socialtool.com" },
    });

    if (existingUser) {
      return NextResponse.json({
        success: true,
        message: "Seed data already exists",
      });
    }

    // Create the demo user
    const user = await db.user.create({
      data: {
        email: "demo@socialtool.com",
        name: "Demo User",
        bio: "Social media enthusiast | Content creator | Growth hacker",
        timezone: "America/New_York",
      },
    });

    // Create 6 SocialAccounts
    const accounts = await Promise.all([
      db.socialAccount.create({
        data: {
          userId: user.id,
          platform: "instagram",
          username: "demo_instagram",
          displayName: "Demo Instagram",
          followers: 125400,
          following: 890,
        },
      }),
      db.socialAccount.create({
        data: {
          userId: user.id,
          platform: "twitter",
          username: "demo_twitter",
          displayName: "Demo Twitter",
          followers: 83200,
          following: 1240,
        },
      }),
      db.socialAccount.create({
        data: {
          userId: user.id,
          platform: "facebook",
          username: "demo_facebook",
          displayName: "Demo Facebook",
          followers: 45600,
          following: 320,
        },
      }),
      db.socialAccount.create({
        data: {
          userId: user.id,
          platform: "tiktok",
          username: "demo_tiktok",
          displayName: "Demo TikTok",
          followers: 312000,
          following: 450,
        },
      }),
      db.socialAccount.create({
        data: {
          userId: user.id,
          platform: "youtube",
          username: "demo_youtube",
          displayName: "Demo YouTube",
          followers: 27800,
          following: 180,
        },
      }),
      db.socialAccount.create({
        data: {
          userId: user.id,
          platform: "linkedin",
          username: "demo_linkedin",
          displayName: "Demo LinkedIn",
          followers: 15400,
          following: 560,
        },
      }),
    ]);

    // Create sample posts
    const postsData = [
      { userId: user.id, accountId: accounts[0].id, platforms: "instagram", content: "Want to boost your Instagram engagement? Here are 5 proven strategies that helped us grow by 300% in just 3 months! 📈 #SocialMedia #GrowthTips", status: "published", likes: 1247, comments: 89, shares: 203, views: 15400, publishedAt: new Date("2024-01-15T10:00:00Z") },
      { userId: user.id, accountId: accounts[1].id, platforms: "twitter", content: "Thread: The ultimate guide to Twitter/X marketing in 2024. From algorithm changes to content strategies — everything you need to know. 🧵👇", status: "published", likes: 562, comments: 134, shares: 421, views: 28900, publishedAt: new Date("2024-01-18T14:30:00Z") },
      { userId: user.id, accountId: accounts[2].id, platforms: "facebook", content: "Join our free webinar this Friday: 'Facebook Ads Mastery — From Zero to Hero'. Limited spots available!", status: "scheduled", scheduledAt: new Date("2024-02-20T16:00:00Z") },
      { userId: user.id, accountId: accounts[3].id, platforms: "tiktok", content: "POV: You just discovered the power of TikTok trends for your brand 🎬", status: "published", likes: 8934, comments: 567, shares: 2100, views: 245000, publishedAt: new Date("2024-01-20T09:15:00Z") },
      { userId: user.id, accountId: accounts[4].id, platforms: "youtube", content: "How I grew my YouTube channel from 0 to 25K subscribers using only organic strategies.", status: "published", likes: 1876, comments: 234, shares: 156, views: 89000, publishedAt: new Date("2024-01-22T12:00:00Z") },
      { userId: user.id, accountId: accounts[5].id, platforms: "linkedin", content: "After managing social media for 50+ brands, here's the one thing that separates successful campaigns from the rest: Consistency.", status: "published", likes: 423, comments: 78, shares: 156, views: 12300, publishedAt: new Date("2024-01-25T08:00:00Z") },
    ];

    const posts: any[] = [];
    for (const postData of postsData) {
      const post = await db.post.create({ data: postData });
      posts.push(post);
    }

    // Create sample comments
    const commentsData = [
      { postId: posts[0].id, author: "Sarah Mitchell", content: "These tips are gold! Implemented #3 and already seeing results.", platform: "instagram", isRead: true, isReplied: true, reply: "So glad to hear that, Sarah! Keep us posted." },
      { postId: posts[0].id, author: "Mike Chen", content: "Can you do a follow-up on hashtag strategy?", platform: "instagram", isRead: false },
      { postId: posts[1].id, author: "Alex Rivera", content: "This thread is incredibly comprehensive. Bookmarked!", platform: "twitter", isRead: true, isReplied: true },
      { postId: posts[3].id, author: "Emily Watson", content: "OMG this went viral!! The editing is chef's kiss!", platform: "tiktok", isRead: true, isReplied: true },
      { postId: posts[4].id, author: "Robert Kim", content: "Best YouTube growth video I've seen all year.", platform: "youtube", isRead: false },
    ];

    await Promise.all(commentsData.map((c) => db.comment.create({ data: c })));

    // Create campaigns
    await Promise.all([
      db.campaign.create({ data: { name: "Instagram Growth Boost", type: "like", platforms: "instagram", targetCount: 500, currentCount: 342, status: "active" } }),
      db.campaign.create({ data: { name: "Twitter Engagement Push", type: "comment", platforms: "twitter", targetCount: 200, currentCount: 89, status: "active" } }),
      db.campaign.create({ data: { name: "LinkedIn Authority Builder", type: "like", platforms: "linkedin", targetCount: 300, currentCount: 300, status: "completed", endedAt: new Date("2024-02-01T00:00:00Z") } }),
    ]);

    // Create UserSettings
    await db.userSettings.create({
      data: {
        userId: user.id,
        emailNotifications: true,
        pushNotifications: true,
        postPublishedNotify: true,
        commentAlerts: true,
        campaignCompletion: true,
        weeklyAnalyticsDigest: true,
        trendAlerts: false,
        theme: "system",
        compactMode: false,
        sidebarDefaultExpanded: true,
      },
    });

    // Create Notifications
    const now = Date.now();
    await Promise.all([
      db.notification.create({ data: { userId: user.id, type: "post", title: "Post Published", message: "Your Instagram post was published successfully.", read: true, createdAt: new Date(now - 3600000 * 2) } }),
      db.notification.create({ data: { userId: user.id, type: "comment", title: "New Comment", message: "Sarah Mitchell commented: 'These tips are gold!'", read: false, createdAt: new Date(now - 3600000) } }),
      db.notification.create({ data: { userId: user.id, type: "campaign", title: "Campaign Completed", message: "LinkedIn Authority Builder reached its target of 300 likes.", read: false, createdAt: new Date(now - 1800000) } }),
      db.notification.create({ data: { userId: user.id, type: "trend", title: "Trending Topic Alert", message: "'AI Marketing' is trending on Twitter/X with 74K+ mentions.", read: false, createdAt: new Date(now - 900000) } }),
      db.notification.create({ data: { userId: user.id, type: "system", title: "Welcome to SocialPilot!", message: "Get started by connecting your social media accounts.", read: true, createdAt: new Date(now - 86400000) } }),
      db.notification.create({ data: { userId: user.id, type: "comment", title: "New Comment", message: "Emily Watson commented on your TikTok: 'OMG this went viral!!'", read: false, createdAt: new Date(now - 600000) } }),
      db.notification.create({ data: { userId: user.id, type: "post", title: "Post Scheduled", message: "Your Facebook post has been scheduled for Feb 20.", read: true, createdAt: new Date(now - 7200000) } }),
    ]);

    // Create sample API key
    await db.apiKey.create({
      data: {
        userId: user.id,
        label: "Development Key",
        key: "sp_dev_" + crypto.randomUUID().replace(/-/g, ""),
      },
    });

    return NextResponse.json({
      success: true,
      message: "Seed data created",
    });
  } catch (error) {
    console.error("Seed error:", error);
    return NextResponse.json(
      { success: false, message: "Failed to seed database" },
      { status: 500 }
    );
  }
}
