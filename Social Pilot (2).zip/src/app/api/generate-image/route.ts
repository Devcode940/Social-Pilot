import { NextRequest, NextResponse } from "next/server";
import ZAI from "z-ai-web-dev-sdk";
import { writeFile, mkdir } from "fs/promises";
import { join } from "path";
import sharp from "sharp";

const UPLOAD_DIR = join(process.cwd(), "public", "uploads");

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { prompt, size } = body as { prompt: string; size?: string };

    if (!prompt || typeof prompt !== "string" || prompt.trim().length === 0) {
      return NextResponse.json(
        { message: "A prompt is required for image generation." },
        { status: 400 }
      );
    }

    // Ensure uploads directory exists
    await mkdir(UPLOAD_DIR, { recursive: true });

    // Generate image using z-ai-web-dev-sdk
    const zai = await ZAI.create();
    const validSizes = ["1024x1024", "768x1344", "864x1152", "1344x768", "1152x864", "1440x720", "720x1440"] as const;
    const selectedSize = (validSizes as readonly string[]).includes(size || "") ? (size as typeof validSizes[number]) : "1024x1024";

    const response = await zai.images.generations.create({
      prompt: prompt.trim(),
      size: selectedSize,
    });

    const base64Image = response.data?.[0]?.base64;

    if (!base64Image) {
      return NextResponse.json(
        { message: "AI image generation returned no image data." },
        { status: 500 }
      );
    }

    // Save the image to disk
    const timestamp = Date.now();
    const randomStr = Math.random().toString(36).substring(2, 8);
    const filename = `ai-${timestamp}-${randomStr}.png`;
    const filePath = join(UPLOAD_DIR, filename);

    const buffer = Buffer.from(base64Image, "base64");
    await writeFile(filePath, buffer);

    // Create thumbnail
    const thumbFilename = `thumb-${filename}`;
    const thumbPath = join(UPLOAD_DIR, thumbFilename);

    try {
      await sharp(buffer)
        .resize(300, 300, { fit: "cover" })
        .toFile(thumbPath);
    } catch (err) {
      console.error("Thumbnail creation failed for AI image:", err);
    }

    const url = `/uploads/${filename}`;
    const thumbnail = `/uploads/${thumbFilename}`;

    return NextResponse.json({
      url,
      thumbnail,
      name: `AI: ${prompt.slice(0, 50)}${prompt.length > 50 ? "..." : ""}`,
      size: buffer.length,
      type: "image",
    });
  } catch (error) {
    console.error("POST /api/generate-image error:", error);
    return NextResponse.json(
      {
        message:
          error instanceof Error
            ? `AI image generation failed: ${error.message}`
            : "Failed to generate image. Please try again.",
      },
      { status: 500 }
    );
  }
}
