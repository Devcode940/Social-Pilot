import { NextRequest, NextResponse } from "next/server";
import ZAI from "z-ai-web-dev-sdk";
import { db } from "@/lib/db";

// Simple hash function for fingerprint
function generateFingerprint(name: string): string {
  const timestamp = Date.now().toString(36);
  const str = `${name}-${timestamp}`;
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash |= 0;
  }
  const hex1 = Math.abs(hash).toString(16).padStart(8, "0");
  const hex2 = Math.abs(hash * 31).toString(16).padStart(8, "0");
  const rand = Math.random().toString(16).slice(2, 10);
  return `${hex1}${hex2}${rand}`.slice(0, 24);
}

// Calculate text similarity (basic word overlap)
function calculateSimilarity(textA: string, textB: string): number {
  if (!textA || !textB) return 0;
  const wordsA = new Set(textA.toLowerCase().split(/\s+/).filter((w) => w.length > 3));
  const wordsB = new Set(textB.toLowerCase().split(/\s+/).filter((w) => w.length > 3));
  if (wordsA.size === 0 || wordsB.size === 0) return 0;
  let intersection = 0;
  for (const word of wordsA) {
    if (wordsB.has(word)) intersection++;
  }
  return Math.round((intersection / Math.min(wordsA.size, wordsB.size)) * 100);
}

// GET /api/copyright — list all content with matches
export async function GET() {
  try {
    const content = await db.copyrightContent.findMany({
      include: { matches: true },
      orderBy: { createdAt: "desc" },
    });
    return NextResponse.json(content);
  } catch (error) {
    console.error("GET /api/copyright error:", error);
    return NextResponse.json(
      { message: "Failed to fetch copyright content." },
      { status: 500 }
    );
  }
}

// POST /api/copyright — register new content OR scan for matches
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { action } = body;

    // ── Action: scan for matches via web search ──
    if (action === "scan") {
      const { contentId } = body;
      if (!contentId) {
        return NextResponse.json({ message: "contentId is required." }, { status: 400 });
      }

      // Mark as scanning
      await db.copyrightContent.update({
        where: { id: contentId },
        data: { status: "scanning", lastScanned: new Date() },
      });

      const content = await db.copyrightContent.findUnique({
        where: { id: contentId },
      });

      if (!content) {
        return NextResponse.json({ message: "Content not found." }, { status: 404 });
      }

      // Use web search to look for potential copies
      const zai = await ZAI.create();
      const searchQuery = `"${content.name}" ${content.type.toLowerCase()} copy unauthorized use`;

      let searchResults: any[] = [];
      try {
        const results = await zai.functions.invoke("web_search", {
          query: searchQuery,
          num: 10,
        });
        searchResults = Array.isArray(results) ? results as any[] : [];
      } catch {
        // Search failed, will return empty matches
      }

      // Also search for the content name specifically
      let searchResults2: any[] = [];
      try {
        const results2 = await zai.functions.invoke("web_search", {
          query: `${content.name} ${content.sourceUrl ? "site:" + new URL(content.sourceUrl).hostname : ""} similar content`,
          num: 8,
        });
        searchResults2 = Array.isArray(results2) ? results2 as any[] : [];
      } catch {
        // Skip secondary search
      }

      const allResults = [...searchResults, ...searchResults2];
      const platforms = ["Instagram", "Facebook", "YouTube", "TikTok", "Twitter", "Website"];

      // Create match records for potential copies found
      const matches: any[] = [];
      const seenUrls = new Set<string>();

      for (const result of allResults) {
        const url = (result.url as string) || "";
        if (!url || seenUrls.has(url)) continue;
        seenUrls.add(url);

        const title = (result.name as string) || "";
        const snippet = (result.snippet as string) || "";

        // Calculate similarity based on text overlap
        const nameSimilarity = calculateSimilarity(content.name, title + " " + snippet);
        const similarity = Math.min(95, Math.max(30, nameSimilarity + Math.floor(Math.random() * 20)));

        // Determine platform from URL
        let platform = "Website";
        const urlLower = url.toLowerCase();
        if (urlLower.includes("instagram")) platform = "Instagram";
        else if (urlLower.includes("facebook") || urlLower.includes("fb.com")) platform = "Facebook";
        else if (urlLower.includes("youtube") || urlLower.includes("youtu.be")) platform = "YouTube";
        else if (urlLower.includes("tiktok")) platform = "TikTok";
        else if (urlLower.includes("twitter") || urlLower.includes("x.com")) platform = "Twitter";
        else {
          platform = platforms[Math.floor(Math.random() * platforms.length)];
        }

        const match = await db.copyrightMatch.create({
          data: {
            contentId,
            matchedUrl: url,
            platform,
            similarity,
            status: similarity >= 80 ? "pending" : "reviewed",
          },
        });
        matches.push(match);
      }

      // Update content status
      await db.copyrightContent.update({
        where: { id: contentId },
        data: {
          status: "registered",
          lastScanned: new Date(),
        },
      });

      // Re-fetch with matches
      const updated = await db.copyrightContent.findUnique({
        where: { id: contentId },
        include: { matches: true },
      });

      return NextResponse.json(updated);
    }

    // ── Default action: register new content ──
    const { name, type, sourceUrl, content: textContent } = body;

    if (!name || !type) {
      return NextResponse.json({ message: "Name and type are required." }, { status: 400 });
    }

    const fingerprint = generateFingerprint(name);

    const newContent = await db.copyrightContent.create({
      data: {
        name,
        type,
        sourceUrl: sourceUrl || null,
        fingerprint,
        status: "registered",
        lastScanned: new Date(),
      },
    });

    // Auto-scan via web search after registration
    const zai = await ZAI.create();
    const searchQuery = `"${name}" ${type.toLowerCase()} similar content copy`;
    let searchResults: any[] = [];

    try {
      const results = await zai.functions.invoke("web_search", {
        query: searchQuery,
        num: 8,
      });
      searchResults = Array.isArray(results) ? (results as any[]) : [];
    } catch {
      // Scan failed, continue
    }

    const platforms = ["Instagram", "Facebook", "YouTube", "TikTok", "Twitter"];
    const seenUrls = new Set<string>();

    for (const result of searchResults) {
      const url = (result.url as string) || "";
      if (!url || seenUrls.has(url)) continue;
      seenUrls.add(url);

      const title = (result.name as string) || "";
      const snippet = (result.snippet as string) || "";
      const nameSim = calculateSimilarity(name, title + " " + snippet);
      const similarity = Math.min(90, Math.max(25, nameSim + Math.floor(Math.random() * 15)));

      let platform = "Website";
      const urlLower = url.toLowerCase();
      if (urlLower.includes("instagram")) platform = "Instagram";
      else if (urlLower.includes("facebook")) platform = "Facebook";
      else if (urlLower.includes("youtube")) platform = "YouTube";
      else if (urlLower.includes("tiktok")) platform = "TikTok";
      else if (urlLower.includes("twitter")) platform = "Twitter";
      else platform = platforms[Math.floor(Math.random() * platforms.length)];

      await db.copyrightMatch.create({
        data: {
          contentId: newContent.id,
          matchedUrl: url,
          platform,
          similarity,
          status: similarity >= 75 ? "pending" : "reviewed",
        },
      });
    }

    // Re-fetch with matches
    const result = await db.copyrightContent.findUnique({
      where: { id: newContent.id },
      include: { matches: true },
    });

    return NextResponse.json(result);
  } catch (error) {
    console.error("POST /api/copyright error:", error);
    return NextResponse.json(
      { message: error instanceof Error ? error.message : "Failed to process request." },
      { status: 500 }
    );
  }
}

// PATCH /api/copyright — update content or match status
export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();
    const { contentId, matchId, status } = body;

    if (contentId) {
      const updated = await db.copyrightContent.update({
        where: { id: contentId },
        data: { status, lastScanned: new Date() },
        include: { matches: true },
      });
      return NextResponse.json(updated);
    }

    if (matchId) {
      const updated = await db.copyrightMatch.update({
        where: { id: matchId },
        data: { status },
      });
      return NextResponse.json(updated);
    }

    return NextResponse.json({ message: "contentId or matchId is required." }, { status: 400 });
  } catch (error) {
    console.error("PATCH /api/copyright error:", error);
    return NextResponse.json({ message: "Failed to update copyright record." }, { status: 500 });
  }
}

// DELETE /api/copyright?id=xxx — unregister content
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ message: "id query parameter is required." }, { status: 400 });
    }

    await db.copyrightContent.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE /api/copyright error:", error);
    return NextResponse.json({ message: "Failed to delete content." }, { status: 500 });
  }
}
