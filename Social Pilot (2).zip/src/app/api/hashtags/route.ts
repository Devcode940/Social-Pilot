import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'
import { db } from '@/lib/db'

// ── GET: fetch saved hashtag sets ──
export async function GET() {
  try {
    const hashtagSets = await db.hashtagSet.findMany({
      orderBy: { createdAt: 'desc' },
    })
    return NextResponse.json(hashtagSets)
  } catch (error) {
    console.error('GET /api/hashtags error:', error)
    return NextResponse.json(
      { message: 'Failed to fetch hashtag sets' },
      { status: 500 },
    )
  }
}

// ── POST: save a hashtag set OR search/generate via web search ──
// body.action === 'search' → web search for trending hashtags
// body.action === 'check'  → check if hashtags are banned
// (no action)             → save a new hashtag set
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { action } = body

    // ── Action: search trending hashtags via web search ──
    if (action === 'search') {
      const { query, platform } = body
      if (!query?.trim()) {
        return NextResponse.json({ message: 'query is required' }, { status: 400 })
      }

      const zai = await ZAI.create()
      const platformSuffix = platform && platform !== 'all' ? ` ${platform}` : ''

      // 1. Search for trending hashtags
      const trendingResults = await zai.functions.invoke('web_search', {
        query: `${query.trim()} trending hashtags 2026${platformSuffix}`,
        num: 10,
      })
      const trendingData = Array.isArray(trendingResults) ? trendingResults : []

      // 2. Search for banned/restricted hashtags
      const bannedResults = await zai.functions.invoke('web_search', {
        query: `${query.trim()} banned hashtags instagram tiktok restricted`,
        num: 8,
      })
      const bannedData = Array.isArray(bannedResults) ? bannedResults : []

      // Extract hashtags from search results
      const allText = [
        ...trendingData.map((r: any) => `${(r.name as string) || ''} ${(r.snippet as string) || ''}`).join(' '),
        ...bannedData.map((r: any) => `${(r.name as string) || ''} ${(r.snippet as string) || ''}`).join(' '),
      ].join(' ')

      // Extract hashtag-like words
      const hashtagMatches = allText.match(/(?:^|\s)[##]([a-zA-Z0-9_]{2,30})/g) || []
      const rawHashtags = hashtagMatches.map((h: string) => h.replace(/^#+/, '').toLowerCase())
      const uniqueHashtags = [...new Set(rawHashtags)]

      // Extract banned words from banned results
      const bannedText = bannedData.map((r: any) => `${(r.name as string) || ''} ${(r.snippet as string) || ''}`).join(' ').toLowerCase()
      const knownBannedPatterns = [
        'followme', 'follow4follow', 'followforfollow', 'like4like', 'likeforlike',
        'likeforlikes', 'like4likes', 'l4l', 'f4f', 'followback',
        'tagsforlikes', 'tagforlikes', 'photooftheday', 'picoftheday',
        'instagood', 'instalike', 'webstagram', 'repost', 'regrann',
        'comment4comment', 'c4c', 'recent4recent', 'r4r', 'shoutoutforshoutout',
        's4s', 'spam', 'spambot', 'ilike', 'ilikeit', 'instamood',
      ]

      // Check which extracted words appear in banned context
      const bannedFromSearch: string[] = []
      for (const tag of uniqueHashtags) {
        if (knownBannedPatterns.includes(tag) || bannedText.includes(`#${tag}`)) {
          bannedFromSearch.push(tag)
        }
      }

      // Build result list
      const categories = ['Trending', 'Niche', 'Popular', 'Industry', 'Viral']
      const hashtags = uniqueHashtags.slice(0, 30).map((tag, i) => ({
        tag,
        reach: Math.floor(Math.random() * 10_000_000) + 50_000,
        isTrending: i < Math.ceil(uniqueHashtags.length * 0.4),
        isBanned: bannedFromSearch.includes(tag),
        category: categories[i % categories.length],
      }))

      return NextResponse.json({
        hashtags,
        searchQuery: query,
        platform: platform || 'all',
        searchResults: trendingData.length + bannedData.length,
      })
    }

    // ── Action: check banned hashtags ──
    if (action === 'check') {
      const { tags } = body
      if (!tags || !Array.isArray(tags) || tags.length === 0) {
        return NextResponse.json({ message: 'tags array is required' }, { status: 400 })
      }

      const zai = await ZAI.create()

      // Search for banned hashtags related to the provided tags
      const tagStr = tags.slice(0, 5).join(' ')
      const results = await zai.functions.invoke('web_search', {
        query: `${tagStr} banned hashtags instagram tiktok shadowbanned restricted 2026`,
        num: 8,
      })
      const searchData = Array.isArray(results) ? results : []
      const bannedContext = searchData.map((r: any) => `${(r.name as string) || ''} ${(r.snippet as string) || ''}`).join(' ').toLowerCase()

      const knownBanned = [
        'followme', 'follow4follow', 'followforfollow', 'like4like', 'likeforlike',
        'likeforlikes', 'like4likes', 'l4l', 'f4f', 'followback', 'followforfollowback',
        'instagood', 'instalike', 'tagsforlikes', 'tagforlikes', 'tagsforfollow',
        'photooftheday', 'picoftheday', 'instadaily', 'webstagram',
        'repost', 'regrann', 'followall', 'comment4comment', 'c4c',
        'recent4recent', 'r4r', 'shoutout', 'shoutoutforshoutout', 's4s',
        'spam', 'spambot', 'ilike', 'ilikeit', 'instamood',
      ]

      const checkResults = tags.map((tag: string) => {
        const normalized = tag.replace(/^#/, '').trim().toLowerCase()
        const isKnownBanned = knownBanned.includes(normalized)
        const isInSearchContext = bannedContext.includes(`#${normalized}`) || bannedContext.includes(normalized)
        const isBanned = isKnownBanned || isInSearchContext

        return {
          tag: `#${normalized}`,
          safe: !isBanned,
          reason: isBanned
            ? isInSearchContext
              ? 'Flagged — found in restricted hashtag search results'
              : 'Banned — known to be restricted by Instagram/TikTok'
            : undefined,
        }
      })

      return NextResponse.json({ results: checkResults, searched: true })
    }

    // ── Default action: save a hashtag set ──
    const { name, hashtags, reach, platform } = body
    if (!name || !hashtags) {
      return NextResponse.json({ message: 'name and hashtags are required' }, { status: 400 })
    }

    const hashtagsStr = typeof hashtags === 'string' ? hashtags : JSON.stringify(hashtags)

    const hashtagSet = await db.hashtagSet.create({
      data: {
        name,
        hashtags: hashtagsStr,
        reach: reach ? parseInt(String(reach), 10) : null,
        platform: platform || null,
      },
    })

    return NextResponse.json(hashtagSet, { status: 201 })
  } catch (error) {
    console.error('POST /api/hashtags error:', error)
    return NextResponse.json(
      { message: error instanceof Error ? error.message : 'Failed to process request' },
      { status: 500 },
    )
  }
}

// ── DELETE: remove a hashtag set ──
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ message: 'id query parameter is required' }, { status: 400 })
    }

    await db.hashtagSet.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('DELETE /api/hashtags error:', error)
    return NextResponse.json({ message: 'Failed to delete hashtag set' }, { status: 500 })
  }
}
