import { NextRequest, NextResponse } from "next/server";
import ZAI from "z-ai-web-dev-sdk";
import { db } from "@/lib/db";

interface AIVideoRequest {
  prompt: string;
  style?: string;
  format?: string;
  duration?: number;
  settings?: {
    resolution?: string;
    model?: string;
    music?: boolean;
    voiceover?: boolean;
    watermark?: boolean;
  };
}

export async function POST(request: NextRequest) {
  try {
    const body: AIVideoRequest = await request.json();
    const {
      prompt,
      style,
      format,
      duration = 30,
      settings = {},
    } = body;

    const {
      resolution = "1080p",
      model = "default",
      music = false,
      voiceover = false,
      watermark = false,
    } = settings;

    // Build the image generation prompt based on style and video concept
    const imagePrompt = [
      prompt,
      style ? `in ${style} style` : "",
      "professional video thumbnail concept art",
      "cinematic lighting",
      "high quality",
      "detailed",
    ]
      .filter(Boolean)
      .join(", ");

    // Generate image using z-ai-web-dev-sdk
    const zai = await ZAI.create();
    const response = await zai.images.generations.create({
      prompt: imagePrompt,
      size: "1024x1024",
    });

    const base64Image = response.data?.[0]?.base64;

    if (!base64Image) {
      return NextResponse.json(
        { message: "AI image generation returned no image data." },
        { status: 500 }
      );
    }

    const thumbnail = `data:image/png;base64,${base64Image}`;
    const name = `AI Generated: ${prompt.slice(0, 50)}${prompt.length > 50 ? "..." : ""}`;

    // Save as MediaProject in the database with status "exported"
    const mediaProject = await db.mediaProject.create({
      data: {
        name,
        type: "video",
        status: "exported",
        duration,
        thumbnail,
      },
    });

    return NextResponse.json({
      id: mediaProject.id,
      name: mediaProject.name,
      thumbnail: mediaProject.thumbnail,
      status: mediaProject.status,
      format: format || "mp4",
      duration,
    });
  } catch (error) {
    console.error("POST /api/ai-video error:", error);
    return NextResponse.json(
      {
        message:
          error instanceof Error
            ? `AI video generation failed: ${error.message}`
            : "Failed to generate video concept. Please try again.",
      },
      { status: 500 }
    );
  }
}
