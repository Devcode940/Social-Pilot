import { NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/media — list media projects
export async function GET() {
  try {
    const media = await db.mediaProject.findMany({
      orderBy: { createdAt: "desc" },
    });
    return NextResponse.json(media);
  } catch (error) {
    console.error("GET /api/media error:", error);
    return NextResponse.json(
      { message: "Failed to fetch media projects." },
      { status: 500 }
    );
  }
}
